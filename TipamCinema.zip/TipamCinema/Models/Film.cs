﻿using System.ComponentModel.DataAnnotations;
using TipamCinema.Datas.Enums;

namespace TipamCinema.Models
{
    public class Film
    {
        [Key]

        public int Id { get; set; }
        public string Nom { get; set; }
        public string Description { get; set; }
        public string Photo { get; set; }
        public double Prix { get; set; }
        public DateTime Debut { get; set; }
        public DateTime Fin { get; set; }
        public FilmCategorie FilmCategorie { get; set; }

       public  List<Acteur_Film> Acteur_Films { get; set; }
    }
}
