﻿using System.ComponentModel.DataAnnotations;

namespace TipamCinema.Models
{
    public class Acteur
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage ="le nom est requis")]
        [StringLength(50,MinimumLength =2, ErrorMessage ="Le nom doit etre compris entre 2 et 50 caracteres")]
        public string Nom { get; set; }
        [Display(Name ="Photo de profil")]// notation 
        [Required(ErrorMessage = "la photo de profile est requise")]
        public string PhotoProfile { get; set;}

       [Required(ErrorMessage = "la bibiographie est requise")]
        public string Bibiographie { get; set;}
       public  List<Acteur_Film> Acteur_Films{ get; set;}
    }
}
