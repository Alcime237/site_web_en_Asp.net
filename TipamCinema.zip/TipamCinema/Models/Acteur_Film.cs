﻿namespace TipamCinema.Models
{
    public class Acteur_Film
    {
     public int ActeurId {  get; set; }
     public Acteur Acteur { get; set; } 
     public int FilmId {  get; set; }
    public Film Film { get; set; }


    }
}
