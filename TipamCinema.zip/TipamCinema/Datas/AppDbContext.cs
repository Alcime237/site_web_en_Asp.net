﻿using Microsoft.EntityFrameworkCore;
using TipamCinema.Models;

namespace TipamCinema.Datas
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options):base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)

        { 
            // on veut dire ici que les cles on migres
            modelBuilder.Entity<Acteur_Film>().HasKey(af => new

          {
            af.ActeurId,
            af.FilmId


          });

            modelBuilder.Entity<Acteur_Film>().HasOne(f => f.Film)
                                              .WithMany(af => af.Acteur_Films)
                                              .HasForeignKey(af => af.FilmId);

            modelBuilder.Entity<Acteur_Film>().HasOne(a => a.Acteur)
                                              .WithMany(af => af.Acteur_Films)
                                              .HasForeignKey(af => af.ActeurId);

            base.OnModelCreating(modelBuilder);


        }

        public DbSet<Acteur>Acteurs { get; set; } 
        public DbSet<Film> Films { get; set; }
        public DbSet<Acteur_Film> Acteurs_Films { get; set; }

    }
}
