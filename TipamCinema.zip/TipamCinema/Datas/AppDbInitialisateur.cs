﻿using Microsoft.Identity.Client;
using TipamCinema.Datas.Enums;
using TipamCinema.Models;

namespace TipamCinema.Datas
{
    public class AppDbInitialisateur
    {
        public static void Seed(IApplicationBuilder applicationBuilder)
        {

            using (var serviceScope = applicationBuilder.ApplicationServices.CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetService<AppDbContext>();
                context.Database.EnsureCreated();

                // Acteur 

                if (!context.Acteurs.Any())
                {
                    context.Acteurs.AddRange(new List<Acteur>()
                    {
                        new Acteur()
                        {
                            Nom="Acteur1",
                            PhotoProfile="http://dotnethow.net/images/actors/actor-1.jpeg",
                            Bibiographie="information sur l'acteur"

                        },

                        new Acteur()
                          {
                            Nom="Acteur2",
                            PhotoProfile="http://dotnethow.net/images/actors/actor-2.jpeg",
                            Bibiographie="information sur l'acteur"

                        },

                        new Acteur()
                        {
                            Nom="Acteur3",
                            PhotoProfile="http://dotnethow.net/images/actors/actor-3.jpeg",
                            Bibiographie="information sur l'acteur"

                        },

                    });
                    context.SaveChanges();

                }

                // Film
                if (!context.Films.Any())
                {
                    context.Films.AddRange(new List<Film>()
                    {
                        new Film()
                        {
                            Nom = "Film1",
                            Description = "desc1",
                            Photo = "http://dotnethow.net/images/movies/movie-1.jpeg",
                            Prix = 39.25,
                            Debut = DateTime.Now.AddDays(-6),
                            Fin = DateTime.Now.AddDays(-10),
                            FilmCategorie = FilmCategorie.Amour


                        },

                        new Film()
                        {
                            Nom = "Film2",
                            Description = "desc2",
                            Photo = "http://dotnethow.net/images/movies/movie-2.jpeg",
                            Prix = 55.25,
                            Debut = DateTime.Now.AddDays(1),
                            Fin = DateTime.Now.AddDays(2),
                            FilmCategorie = FilmCategorie.Comedie


                        },

                        new Film()
                        {
                            Nom = "Film3",
                            Description = "desc3",
                            Photo = "http://dotnethow.net/images/movies/movie-3.jpeg",
                            Prix = 79.25,
                            Debut = DateTime.Now.AddDays(-3),
                            Fin = DateTime.Now.AddDays(-6),
                            FilmCategorie = FilmCategorie.Horreur

                        },

                    });
                    context.SaveChanges();

                    //Acteur && Film
                    if (!context.Acteurs_Films.Any())
                    {
                        context.Acteurs_Films.AddRange(new List<Acteur_Film>()
                        {
                            new Acteur_Film()
                            {
                                ActeurId = 1,
                                FilmId = 3
                            },
                            new Acteur_Film()
                            {
                                ActeurId = 2,
                                FilmId = 2
                            },
                            new Acteur_Film()
                            {
                                ActeurId = 3,
                                FilmId = 1

                            }


                        });

                        context.SaveChanges();

                    }
                }
            }
        }
    }
}
    

