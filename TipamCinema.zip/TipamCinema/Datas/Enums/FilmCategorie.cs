﻿namespace TipamCinema.Datas.Enums
{
    public enum FilmCategorie
    {
        Action=1,
        Comedie,
        Amour,
        Horreur,
        Documentaire,
        Animation
    }
}
