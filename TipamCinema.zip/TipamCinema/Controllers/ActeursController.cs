﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TipamCinema.Datas;
using TipamCinema.Models;

namespace TipamCinema.Controllers
{
    public class ActeursController : Controller
    {
        private readonly AppDbContext _context;



        public ActeursController(AppDbContext context)
        {
            _context = context;  
        }
        public async Task<IActionResult> Index()
        {
            var data= await _context.Acteurs.OrderBy(a=>a.Nom).ToListAsync();
            return View(data);
        }
        public IActionResult Create()
        {
            return View();
        
        }
        [HttpPost]
        // public async Task<IActionResult> Create([Bind("Nom,PhotoProfile,biographie")]Acteur acteur)
        // {
        //    if (!ModelState.IsValid)
        //    {
        //        return View(acteur); 
        //    }
        public IActionResult Create(Acteur acteur)
        {

            if (_context.Acteurs.Any(d => d.Id.Equals(acteur.Id)))
            {
                ViewBag.Erreur = " Cet acteur existe deja";
                return View(acteur);
            }
            _context.Acteurs.Add(acteur);
            _context.SaveChanges();
            //return RedirectToAction("Index");
            return RedirectToAction(nameof(Index));

        }
    

    }
}
