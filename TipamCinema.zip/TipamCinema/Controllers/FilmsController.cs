﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TipamCinema.Datas;

namespace TipamCinema.Controllers
{
    public class FilmsController : Controller
    {
        private readonly AppDbContext _context;
        public FilmsController(AppDbContext context)
        {
            _context = context; 
        }
        public  async Task<IActionResult> Index()
        {
            var data= await _context.Films.OrderBy(f=>f.Nom).ToListAsync();
            return View(data);
        }
    }
}
